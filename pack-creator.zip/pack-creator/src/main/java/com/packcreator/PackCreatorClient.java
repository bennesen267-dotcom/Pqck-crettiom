package com.packcreator;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class PackCreatorClient implements ClientModInitializer {
	public static final String MOD_ID = "packcreator";

	private static KeyBinding openKey;

	@Override
	public void onInitializeClient() {
		// Controls menu > "Pack Creator" category. The player can rebind it there.
		openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.packcreator.open",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_K,
				"key.categories.packcreator"
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openKey.wasPressed()) {
				if (client.currentScreen == null) {
					client.setScreen(new PackCreatorScreen());
				}
			}
		});
	}
}
