package com.packcreator;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** State that survives closing/reopening the screen during one game session. */
final class PackSession {
	enum Tool { PEN, ERASER, FILL }

	record Entry(boolean block, String ns, String name, int res, int[] pixels) {
		boolean same(boolean block, String ns, String name) {
			return this.block == block && this.ns.equals(ns) && this.name.equals(name);
		}
	}

	static boolean block = false;
	static String name = "";
	static String packName = "MyPack";

	static int res = 128;
	static int[] pixels = new int[128 * 128];

	static int r = 0x55, g = 0xAA, b = 0xFF;
	static Tool tool = Tool.PEN;
	static int brush = 2;

	static final List<Entry> entries = new ArrayList<>();
	static final ArrayDeque<int[]> undo = new ArrayDeque<>();

	private PackSession() {}

	static int argb() {
		return 0xFF000000 | (r << 16) | (g << 8) | b;
	}

	static int channel(int i) {
		return i == 0 ? r : i == 1 ? g : b;
	}

	static void setChannel(int i, int v) {
		v = Math.max(0, Math.min(255, v));
		if (i == 0) r = v; else if (i == 1) g = v; else b = v;
	}

	static void setColor(int argb) {
		r = (argb >> 16) & 0xFF;
		g = (argb >> 8) & 0xFF;
		b = argb & 0xFF;
	}

	static void pushUndo() {
		undo.push(pixels.clone());
		while (undo.size() > 30) undo.removeLast();
	}

	static int[] resample(int[] src, int from, int to) {
		int[] out = new int[to * to];
		for (int y = 0; y < to; y++) {
			for (int x = 0; x < to; x++) {
				out[y * to + x] = src[(y * from / to) * from + (x * from / to)];
			}
		}
		return out;
	}

	static void addOrReplace(Entry e) {
		for (int i = 0; i < entries.size(); i++) {
			if (entries.get(i).same(e.block(), e.ns(), e.name())) {
				entries.set(i, e);
				return;
			}
		}
		entries.add(e);
	}
}
