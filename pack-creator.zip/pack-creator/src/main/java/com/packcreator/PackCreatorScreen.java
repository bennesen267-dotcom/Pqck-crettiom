package com.packcreator;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.resource.Resource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class PackCreatorScreen extends Screen {
	private static final Identifier CANVAS_ID = new Identifier(PackCreatorClient.MOD_ID, "canvas");
	private static final int[] RES_OPTIONS = {16, 32, 64, 128};
	private static final int[] BRUSH_OPTIONS = {1, 2, 3, 4, 6, 8};
	private static final int PACK_FORMAT = 15; // 1.20 - 1.20.1

	private NativeImageBackedTexture texture;
	private int cx, cy, size;
	private int listX, listW, listY, maxLines;

	private boolean dragging;
	private int lastX = -1, lastY = -1;
	private boolean syncing;

	private ButtonWidget itemTab, blockTab, resButton, toolButton, brushButton;
	private TextFieldWidget nameField, hexField, packField;

	private Text status = Text.empty();
	private int statusColor = 0xFFFFFF;

	public PackCreatorScreen() {
		super(Text.translatable("screen.packcreator.title"));
	}

	// ------------------------------------------------------------------ layout

	@Override
	protected void init() {
		size = Math.max(64, Math.min(256, Math.min(height - 72, width - 210)));
		cx = 10;
		cy = 32;
		listX = cx + size + 12;
		listW = Math.max(120, Math.min(300, width - listX - 10));
		int rx = listX, rw = listW;

		itemTab = addDrawableChild(ButtonWidget.builder(Text.translatable("screen.packcreator.item"), b -> setTab(false))
				.dimensions(10, 8, 60, 16).build());
		blockTab = addDrawableChild(ButtonWidget.builder(Text.translatable("screen.packcreator.block"), b -> setTab(true))
				.dimensions(74, 8, 60, 16).build());

		nameField = new TextFieldWidget(textRenderer, rx, 32, rw, 16, Text.empty());
		nameField.setMaxLength(64);
		nameField.setText(PackSession.name);
		nameField.setChangedListener(s -> {
			PackSession.name = s;
			updateSuggestion();
		});
		addDrawableChild(nameField);

		int bw = (rw - 4) / 3;
		resButton = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> cycleRes())
				.dimensions(rx, 52, bw, 16).build());
		toolButton = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> cycleTool())
				.dimensions(rx + bw + 2, 52, bw, 16).build());
		brushButton = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> cycleBrush())
				.dimensions(rx + 2 * (bw + 2), 52, bw, 16).build());

		for (int i = 0; i < 3; i++) {
			addDrawableChild(new ChannelSlider(rx + i * (bw + 2), 72, bw, 16, i));
		}

		hexField = new TextFieldWidget(textRenderer, rx, 92, rw - 24, 16, Text.empty());
		hexField.setMaxLength(7);
		hexField.setText(hexString());
		hexField.setChangedListener(this::onHex);
		addDrawableChild(hexField);

		int half = (rw - 2) / 2;
		addDrawableChild(ButtonWidget.builder(Text.translatable("screen.packcreator.load"), b -> loadExisting())
				.dimensions(rx, 112, half, 16).build());
		addDrawableChild(ButtonWidget.builder(Text.translatable("screen.packcreator.clear"), b -> clearCanvas())
				.dimensions(rx + half + 2, 112, half, 16).build());
		addDrawableChild(ButtonWidget.builder(Text.translatable("screen.packcreator.add"), b -> addEntry())
				.dimensions(rx, 132, rw, 16).build());

		listY = 154;
		maxLines = Math.max(1, (height - 34 - (listY + 11)) / 10);

		int by = height - 24;
		packField = new TextFieldWidget(textRenderer, 10, by, 150, 18, Text.empty());
		packField.setMaxLength(40);
		packField.setText(PackSession.packName);
		packField.setChangedListener(s -> PackSession.packName = s);
		addDrawableChild(packField);
		addDrawableChild(ButtonWidget.builder(Text.translatable("screen.packcreator.save"), b -> savePack())
				.dimensions(166, by, 110, 18).build());
		addDrawableChild(ButtonWidget.builder(Text.translatable("screen.packcreator.close"), b -> close())
				.dimensions(280, by, 60, 18).build());

		if (texture == null) rebuildTexture();
		updateLabels();
		setTab(PackSession.block);
	}

	@Override
	public void removed() {
		if (client != null && texture != null) {
			client.getTextureManager().destroyTexture(CANVAS_ID);
			texture = null;
		}
	}

	// ------------------------------------------------------------------ texture

	private void rebuildTexture() {
		TextureManager tm = client.getTextureManager();
		if (texture != null) tm.destroyTexture(CANVAS_ID);
		texture = new NativeImageBackedTexture(PackSession.res, PackSession.res, false);
		tm.registerTexture(CANVAS_ID, texture);
		refreshTexture();
	}

	private void refreshTexture() {
		NativeImage img = texture.getImage();
		int res = PackSession.res;
		for (int y = 0; y < res; y++) {
			for (int x = 0; x < res; x++) {
				img.setColor(x, y, swapRB(PackSession.pixels[y * res + x]));
			}
		}
		texture.upload();
	}

	/** ARGB <-> ABGR (the swap is symmetric). */
	private static int swapRB(int c) {
		return (c & 0xFF00FF00) | ((c & 0xFF) << 16) | ((c >> 16) & 0xFF);
	}

	// ------------------------------------------------------------------ UI state

	private void setTab(boolean block) {
		PackSession.block = block;
		itemTab.active = block;
		blockTab.active = !block;
		updateSuggestion();
	}

	private void updateSuggestion() {
		if (nameField == null) return;
		String ex = Text.translatable(PackSession.block
				? "screen.packcreator.example.block" : "screen.packcreator.example.item").getString();
		nameField.setSuggestion(nameField.getText().isEmpty() ? ex : null);
	}

	private void updateLabels() {
		resButton.setMessage(Text.literal(PackSession.res + "x" + PackSession.res));
		toolButton.setMessage(Text.translatable("screen.packcreator.tool." + PackSession.tool.name().toLowerCase(Locale.ROOT)));
		brushButton.setMessage(Text.translatable("screen.packcreator.brush", PackSession.brush));
	}

	private void cycleRes() {
		int i = 0;
		for (int k = 0; k < RES_OPTIONS.length; k++) if (RES_OPTIONS[k] == PackSession.res) i = k;
		int next = RES_OPTIONS[(i + 1) % RES_OPTIONS.length];
		PackSession.pixels = PackSession.resample(PackSession.pixels, PackSession.res, next);
		PackSession.res = next;
		PackSession.undo.clear();
		rebuildTexture();
		updateLabels();
	}

	private void cycleTool() {
		PackSession.Tool[] t = PackSession.Tool.values();
		PackSession.tool = t[(PackSession.tool.ordinal() + 1) % t.length];
		updateLabels();
	}

	private void cycleBrush() {
		int i = 0;
		for (int k = 0; k < BRUSH_OPTIONS.length; k++) if (BRUSH_OPTIONS[k] == PackSession.brush) i = k;
		PackSession.brush = BRUSH_OPTIONS[(i + 1) % BRUSH_OPTIONS.length];
		updateLabels();
	}

	private String hexString() {
		return String.format("#%02X%02X%02X", PackSession.r, PackSession.g, PackSession.b);
	}

	private void onHex(String s) {
		if (syncing) return;
		String h = s.startsWith("#") ? s.substring(1) : s;
		if (h.length() != 6) return;
		try {
			PackSession.setColor(Integer.parseInt(h, 16));
			syncing = true;
			for (var child : children()) {
				if (child instanceof ChannelSlider sl) sl.set(PackSession.channel(sl.channel));
			}
			syncing = false;
		} catch (NumberFormatException ignored) {
		}
	}

	private void setStatus(Text t, boolean ok) {
		status = t;
		statusColor = ok ? 0x55FF55 : 0xFF5555;
	}

	// ------------------------------------------------------------------ drawing tools

	private void paintAt(int px, int py) {
		int res = PackSession.res, b = PackSession.brush;
		int color = PackSession.tool == PackSession.Tool.ERASER ? 0 : PackSession.argb();
		int start = -(b - 1) / 2;
		for (int dy = 0; dy < b; dy++) {
			for (int dx = 0; dx < b; dx++) {
				int x = px + start + dx, y = py + start + dy;
				if (x >= 0 && y >= 0 && x < res && y < res) PackSession.pixels[y * res + x] = color;
			}
		}
	}

	private void line(int x0, int y0, int x1, int y1) {
		int dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0);
		int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
		int err = dx + dy;
		while (true) {
			paintAt(x0, y0);
			if (x0 == x1 && y0 == y1) break;
			int e2 = 2 * err;
			if (e2 >= dy) { err += dy; x0 += sx; }
			if (e2 <= dx) { err += dx; y0 += sy; }
		}
	}

	private void floodFill(int px, int py) {
		int res = PackSession.res;
		int[] p = PackSession.pixels;
		int target = p[py * res + px];
		int repl = PackSession.argb();
		if (target == repl) return;
		ArrayDeque<Integer> stack = new ArrayDeque<>();
		stack.push(py * res + px);
		while (!stack.isEmpty()) {
			int i = stack.pop();
			if (p[i] != target) continue;
			p[i] = repl;
			int x = i % res, y = i / res;
			if (x > 0) stack.push(i - 1);
			if (x < res - 1) stack.push(i + 1);
			if (y > 0) stack.push(i - res);
			if (y < res - 1) stack.push(i + res);
		}
	}

	private void clearCanvas() {
		PackSession.pushUndo();
		java.util.Arrays.fill(PackSession.pixels, 0);
		refreshTexture();
	}

	private void undo() {
		if (PackSession.undo.isEmpty()) return;
		PackSession.pixels = PackSession.undo.pop();
		refreshTexture();
	}

	private boolean inCanvas(double mx, double my) {
		return mx >= cx && my >= cy && mx < cx + size && my < cy + size;
	}

	private int toPixel(double v, int origin) {
		int p = (int) Math.floor((v - origin) * PackSession.res / size);
		return Math.max(0, Math.min(PackSession.res - 1, p));
	}

	// ------------------------------------------------------------------ names / entries

	/** @return {namespace, name} or null if invalid */
	private String[] parseName(String raw) {
		String s = raw.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
		String ns = "minecraft";
		int c = s.indexOf(':');
		if (c >= 0) {
			ns = s.substring(0, c);
			s = s.substring(c + 1);
		}
		if (s.isEmpty() || !s.matches("[a-z0-9_./-]+") || !ns.matches("[a-z0-9_.-]+") || s.contains("..")
				|| s.startsWith("/") || s.endsWith("/")) {
			return null;
		}
		return new String[]{ns, s};
	}

	private static String label(PackSession.Entry e) {
		return e.ns().equals("minecraft") ? e.name() : e.ns() + ":" + e.name();
	}

	private void addEntry() {
		String[] id = parseName(nameField.getText());
		if (id == null) {
			setStatus(Text.translatable("screen.packcreator.status.invalid_name"), false);
			return;
		}
		PackSession.Entry e = new PackSession.Entry(PackSession.block, id[0], id[1], PackSession.res, PackSession.pixels.clone());
		PackSession.addOrReplace(e);
		setStatus(Text.translatable("screen.packcreator.status.added", label(e)), true);
	}

	private void loadExisting() {
		String[] id = parseName(nameField.getText());
		if (id == null) {
			setStatus(Text.translatable("screen.packcreator.status.invalid_name"), false);
			return;
		}
		Identifier tex = new Identifier(id[0], "textures/" + (PackSession.block ? "block" : "item") + "/" + id[1] + ".png");
		Optional<Resource> res = client.getResourceManager().getResource(tex);
		if (res.isEmpty()) {
			setStatus(Text.translatable("screen.packcreator.status.load_failed", id[1]), false);
			return;
		}
		try (InputStream in = res.get().getInputStream(); NativeImage src = NativeImage.read(in)) {
			PackSession.pushUndo();
			int r = PackSession.res;
			int sq = Math.min(src.getWidth(), src.getHeight()); // first frame if animated
			int[] np = new int[r * r];
			for (int y = 0; y < r; y++) {
				for (int x = 0; x < r; x++) {
					np[y * r + x] = swapRB(src.getColor(x * sq / r, y * sq / r));
				}
			}
			PackSession.pixels = np;
			refreshTexture();
			setStatus(Text.translatable("screen.packcreator.status.loaded", id[1]), true);
		} catch (IOException ex) {
			setStatus(Text.translatable("screen.packcreator.status.load_failed", id[1]), false);
		}
	}

	private void loadEntry(PackSession.Entry e) {
		PackSession.undo.clear();
		boolean resChanged = e.res() != PackSession.res;
		PackSession.res = e.res();
		PackSession.pixels = e.pixels().clone();
		PackSession.block = e.block();
		nameField.setText(label(e));
		setTab(e.block());
		if (resChanged) rebuildTexture(); else refreshTexture();
		updateLabels();
	}

	// ------------------------------------------------------------------ saving

	private static byte[] png(int res, int[] px) throws IOException {
		BufferedImage img = new BufferedImage(res, res, BufferedImage.TYPE_INT_ARGB);
		img.setRGB(0, 0, res, res, px, 0, res);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		ImageIO.write(img, "png", out);
		return out.toByteArray();
	}

	private static void put(ZipOutputStream z, String path, byte[] data) throws IOException {
		z.putNextEntry(new ZipEntry(path));
		z.write(data);
		z.closeEntry();
	}

	private void savePack() {
		List<PackSession.Entry> entries = PackSession.entries;
		if (entries.isEmpty()) {
			setStatus(Text.translatable("screen.packcreator.status.empty_pack"), false);
			return;
		}
		String pack = packField.getText().trim().replaceAll("[^A-Za-z0-9 _.-]", "_");
		if (pack.isEmpty()) pack = "MyPack";
		try {
			Path dir = client.runDirectory.toPath().resolve("resourcepacks");
			Files.createDirectories(dir);
			Path zip = dir.resolve(pack + ".zip");
			try (ZipOutputStream z = new ZipOutputStream(Files.newOutputStream(zip))) {
				String mcmeta = "{\"pack\":{\"pack_format\":" + PACK_FORMAT
						+ ",\"description\":\"" + pack + " (Pack Creator)\"}}";
				put(z, "pack.mcmeta", mcmeta.getBytes(StandardCharsets.UTF_8));
				PackSession.Entry first = entries.get(0);
				put(z, "pack.png", png(first.res(), first.pixels()));
				for (PackSession.Entry e : entries) {
					put(z, "assets/" + e.ns() + "/textures/" + (e.block() ? "block" : "item") + "/" + e.name() + ".png",
							png(e.res(), e.pixels()));
				}
			}
			client.getResourcePackManager().scanPacks();
			setStatus(Text.translatable("screen.packcreator.status.saved", pack), true);
		} catch (Exception ex) {
			setStatus(Text.translatable("screen.packcreator.status.save_failed", String.valueOf(ex.getMessage())), false);
		}
	}

	// ------------------------------------------------------------------ input

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		if (inCanvas(mx, my)) {
			setFocused(null);
			int px = toPixel(mx, cx), py = toPixel(my, cy);
			if (button == 1) { // right click = eyedropper
				int c = PackSession.pixels[py * PackSession.res + px];
				if ((c >>> 24) != 0) {
					PackSession.setColor(c);
					syncing = true;
					hexField.setText(hexString());
					for (var child : children()) {
						if (child instanceof ChannelSlider sl) sl.set(PackSession.channel(sl.channel));
					}
					syncing = false;
				}
				return true;
			}
			if (button == 0) {
				PackSession.pushUndo();
				if (PackSession.tool == PackSession.Tool.FILL) {
					floodFill(px, py);
				} else {
					paintAt(px, py);
					dragging = true;
					lastX = px;
					lastY = py;
				}
				refreshTexture();
				return true;
			}
		}

		// entry list
		List<PackSession.Entry> entries = PackSession.entries;
		int linesTop = listY + 11;
		if (mx >= listX && mx < listX + listW && my >= linesTop && !entries.isEmpty()) {
			int start = Math.max(0, entries.size() - maxLines);
			int idx = start + (int) ((my - linesTop) / 10);
			if (idx >= start && idx < entries.size() && (my - linesTop) / 10 < maxLines) {
				PackSession.Entry e = entries.get(idx);
				if (button == 0) {
					loadEntry(e);
				} else if (button == 1) {
					entries.remove(idx);
					setStatus(Text.translatable("screen.packcreator.status.removed", label(e)), true);
				}
				return true;
			}
		}
		return super.mouseClicked(mx, my, button);
	}

	@Override
	public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
		if (dragging && button == 0) {
			int px = toPixel(mx, cx), py = toPixel(my, cy);
			line(lastX, lastY, px, py);
			lastX = px;
			lastY = py;
			refreshTexture();
			return true;
		}
		return super.mouseDragged(mx, my, button, dx, dy);
	}

	@Override
	public boolean mouseReleased(double mx, double my, int button) {
		dragging = false;
		return super.mouseReleased(mx, my, button);
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (keyCode == GLFW.GLFW_KEY_Z && hasControlDown()) {
			undo();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	// ------------------------------------------------------------------ rendering

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		renderBackground(ctx);
		ctx.drawText(textRenderer, title, 142, 12, 0xFFFFFF, true);

		// checkerboard behind the (possibly transparent) canvas
		for (int i = 0; i < 16; i++) {
			for (int j = 0; j < 16; j++) {
				int x1 = cx + i * size / 16, x2 = cx + (i + 1) * size / 16;
				int y1 = cy + j * size / 16, y2 = cy + (j + 1) * size / 16;
				ctx.fill(x1, y1, x2, y2, ((i + j) & 1) == 0 ? 0xFF8A8A8A : 0xFF6E6E6E);
			}
		}
		ctx.drawTexture(CANVAS_ID, cx, cy, size, size, 0, 0, PackSession.res, PackSession.res, PackSession.res, PackSession.res);

		// canvas border
		ctx.fill(cx - 1, cy - 1, cx + size + 1, cy, 0xFFFFFFFF);
		ctx.fill(cx - 1, cy + size, cx + size + 1, cy + size + 1, 0xFFFFFFFF);
		ctx.fill(cx - 1, cy, cx, cy + size, 0xFFFFFFFF);
		ctx.fill(cx + size, cy, cx + size + 1, cy + size, 0xFFFFFFFF);

		// brush outline
		if (inCanvas(mx, my)) {
			int res = PackSession.res, b = PackSession.brush;
			int start = -(b - 1) / 2;
			int px = toPixel(mx, cx), py = toPixel(my, cy);
			int x1 = cx + Math.max(0, px + start) * size / res;
			int x2 = cx + Math.min(res, px + start + b) * size / res;
			int y1 = cy + Math.max(0, py + start) * size / res;
			int y2 = cy + Math.min(res, py + start + b) * size / res;
			ctx.fill(x1, y1, x2, y1 + 1, 0xFFFFFFFF);
			ctx.fill(x1, y2 - 1, x2, y2, 0xFFFFFFFF);
			ctx.fill(x1, y1, x1 + 1, y2, 0xFFFFFFFF);
			ctx.fill(x2 - 1, y1, x2, y2, 0xFFFFFFFF);
		}

		// colour preview next to hex field
		int pvx = listX + listW - 20;
		ctx.fill(pvx - 1, 91, pvx + 17, 109, 0xFFFFFFFF);
		ctx.fill(pvx, 92, pvx + 16, 108, PackSession.argb());

		super.render(ctx, mx, my, delta);

		// entry list
		List<PackSession.Entry> entries = PackSession.entries;
		ctx.drawText(textRenderer, Text.translatable("screen.packcreator.list", entries.size()),
				listX, listY, 0xAAAAAA, false);
		int linesTop = listY + 11;
		int start = Math.max(0, entries.size() - maxLines);
		for (int i = start; i < entries.size(); i++) {
			PackSession.Entry e = entries.get(i);
			int y = linesTop + (i - start) * 10;
			if (mx >= listX && mx < listX + listW && my >= y && my < y + 10) {
				ctx.fill(listX, y, listX + listW, y + 10, 0x40FFFFFF);
			}
			String s = (e.block() ? "[B] " : "[I] ") + label(e) + " (" + e.res() + ")";
			ctx.drawText(textRenderer, Text.literal(textRenderer.trimToWidth(s, listW - 4)), listX + 2, y + 1,
					e.block() ? 0xAAFFAA : 0xFFFFAA, false);
		}

		if (!status.getString().isEmpty()) {
			ctx.drawText(textRenderer, status, 10, height - 35, statusColor, true);
		}
	}

	// ------------------------------------------------------------------ widgets

	private class ChannelSlider extends SliderWidget {
		private final int channel;

		ChannelSlider(int x, int y, int w, int h, int channel) {
			super(x, y, w, h, Text.empty(), PackSession.channel(channel) / 255.0);
			this.channel = channel;
			updateMessage();
		}

		void set(int v) {
			this.value = v / 255.0;
			updateMessage();
		}

		@Override
		protected void updateMessage() {
			setMessage(Text.literal("RGB".charAt(channel) + " " + (int) Math.round(value * 255)));
		}

		@Override
		protected void applyValue() {
			PackSession.setChannel(channel, (int) Math.round(value * 255));
			if (hexField != null && !syncing) {
				syncing = true;
				hexField.setText(hexString());
				syncing = false;
			}
		}
	}
}
