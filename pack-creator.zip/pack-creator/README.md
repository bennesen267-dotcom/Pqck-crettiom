# Pack Creator (Fabric 1.20.1)

Oyun içinde item ve blok dokularını çizip **resource pack** olarak kaydeden istemci modu.

## Kullanım
1. Oyunda **K** tuşuna bas (Ayarlar → Kontroller → **Pack Creator** kategorisinden değiştirilebilir).
2. Üstten **Item** veya **Blok** sekmesini seç.
3. Ad kutusuna dokunun adını yaz (örn. `netherite_sword`, blok için `stone`).
   - İstersen **Mevcut Dokuyu Yükle** ile vanilla dokuyu tuvale çekip üstüne çiz.
4. Çiz: Kalem / Silgi / Doldur, fırça boyutu, RGB kaydırıcılar veya hex. Tuvalde **sağ tık = renk seç**, **Ctrl+Z = geri al**.
5. **Pakete Ekle** (aynı ad tekrar eklenirse üzerine yazar). Listedeki satıra sol tık = düzenle, sağ tık = sil.
6. Altta pack adını yaz → **Kaydet**. Paket `resourcepacks/<ad>.zip` olarak oluşur; Seçenekler → Kaynak Paketleri'nden aç.

Varsayılan çözünürlük 128x; butondan 16 / 32 / 64 / 128 arasında değişir.
Not: Kaydettiğin pack oyunda açıksa Windows dosyayı kilitleyebilir; önce kapat, sonra kaydet.
Adın başına isim alanı koyabilirsin: `mymod:ruby`.

## Derleme
```
gradle wrapper --gradle-version 8.5   # bir kez
./gradlew build                       # jar: build/libs/
./gradlew runClient                   # test için oyunu aç
```
Gereksinim: JDK 17.

## GitHub
```
git init
git add .
git commit -m "Pack Creator"
git branch -M main
git remote add origin https://github.com/KULLANICI/pack-creator.git
git push -u origin main
```
Her push'ta Actions jar'ı derler (Actions → build → Artifacts). `git tag v1.0.0 && git push --tags` ile jar otomatik GitHub Release'e eklenir.
